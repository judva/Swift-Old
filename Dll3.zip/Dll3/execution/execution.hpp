#pragma once
#include "string"

namespace execution {
	void execute(std::string source);
}